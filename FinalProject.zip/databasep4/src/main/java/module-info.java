module com.noahkurtz.databasep4 {
   requires javafx.controls;
    requires com.oracle.database.jdbc;
    requires java.sql;
    requires java.naming;
    exports com.noahkurtz.databasep4;
}
